package com.selenium.pkg;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
public class IElaunch 
{
public static void main(String args[])
				{
			System.setProperty("webdriver.ie.driver","C:\\Users\\DELL\\Downloads\\IEDriverServer_x64_3.141.59\\IEDriverServer.exe");
			WebDriver driver= new InternetExplorerDriver();
			driver.get("https://www.google.com/");
				}

	}


