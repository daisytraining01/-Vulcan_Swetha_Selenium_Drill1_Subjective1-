package com.selenium.pkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BrowserLaunch {
	public static void main(String args[])
			{
		String browser="chrome";
		WebDriver driver = null;
		if(browser.equals("firefox")) {
		System.setProperty("webdriver.gecko.driver","C:\\Users\\DELL\\Downloads\\chromedriver_win32\\geckodriver.exe");
		 driver= new FirefoxDriver();
		}else if(browser.equals("chrome")) {
			
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 driver= new ChromeDriver();
		}else if(browser.equals("ie")) {
			System.setProperty("webdriver.ie.driver","C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");
	     driver= new InternetExplorerDriver();
		}
		//driver.get("https://www.google.com/");
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().window().maximize();
		//Locators--->To identify the objects in the DOM
		//1.ID
		//2.Name
		//3.className
		//4.LinkText
		//5.Partial Linktestx
		//6.xpath
		//7.Tagname
		//8.CSS Selector
		//ID
		/*-
		 * driver.findElement(By.id("username")).sendKeys("tomsmith");
		 * 
		 * driver.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
		 * //xpath d
		 driver.findElement(By.xpath("//button[@type='submit']")).click();*/
		
		//by name 
		
		driver.findElement(By.name("username")).sendKeys("tomsmith");
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("");
		driver.findElement(By.name("password")).sendKeys("SuperSecretPassword!");
		//driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		//driver.findElement(By.linkText("Elemental Selenium")).click();
		driver.findElement(By.xpath("//a[@target='_blank']")).click();
		//a[text()='Elemental Selenium']
		//a[contains(text(),'Elemental Selenium')]
		
		

		//xpath always shoud be in double quotes
		//button--->Tagname
		//[]
		//type is attribute
		//submit is Attribute value
		
		
		
		
		

		
			}                                           
}
